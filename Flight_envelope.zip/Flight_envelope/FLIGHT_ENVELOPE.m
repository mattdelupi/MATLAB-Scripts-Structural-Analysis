function FLIGHT_ENVELOPE(aircraft)
    %% INPUTS
    %   aircraft    =   aircraft name from Aircraft_DATA.xlsx. Must be a
    %                   string and must be equal to the desired sheet's name in
    %                   the Excel spreadsheet (e.g. 'Cessna 172')

    %% INSERT AIRCRAFT FROM DATA SHEETS
    M = readmatrix('Aircrafts_DATA.xlsx', 'Sheet', aircraft, 'Range', 'B1:B11');
    
    %% KNOWN DATA
    VD  =   M(9);           %   Dive speed in KCAS
    VC  =   M(8);           %   Cruising speed in KCAS
    VA  =   M(7);           %   Maneuvering speed in KCAS
    np  =   M(10);          %   Maximum positive load factor
    nn  =   M(11);          %   Maximum negative load factor
    S   =   M(2);           %   Wing area in square feet
    W   =   M(1);           %   Weight in lbs
    G   =   [20 15.25 7.5]; %   Gust speeds in m/s
    h   =   M(6);           %   Height in FL
    CLa =   M(5);           %   CL alpha in 1/deg
    cr  =   M(3);           %   Wing root chord in feet
    tap =   M(4);           %   Wing taper ratio
    
    %% PLOT
    [Vm, nm] = maneuvering(VA, VC, VD, np, nn, S, W);
    hold on
    [Vg, ng] = gust(VA, VC, VD, G, h, CLa, S, W, cr, tap);
    t = ['\textbf{' aircraft '}'];
    title(t, 'Flight Envelope', 'Interpreter', 'latex')
    axis([0 1.15*max([Vm Vg]) 1.15*min([nm ng]) 1.15*max([nm ng])])
    xlabel('Equivalent Air Speed (m/s)', 'Interpreter', 'latex')
    ylabel('Load factor', 'Interpreter', 'latex')
    grid on
    Vt = 0:5:1.15*max([Vm Vg]);
    nt = floor(1.15*min([nm ng])):.5:ceil(1.15*max([nm ng]));
    xticks(Vt)
    yticks(nt)
    legend('Maneuvering Envelope', 'Gust Envelope', 'Interpreter', 'latex')
    set(gca, 'TickLabelInterpreter', 'latex')
end