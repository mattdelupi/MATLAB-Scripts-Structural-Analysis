function SS_PLATE_DEFL(a, b, t, E, v, q, N)
    %% ARGOMENTI IN INPUT
    %   a   =   Lunghezza del lato in x in m
    %   b   =   Lunghezza del lato in y in m
    %   t   =   Spessore della piastra in mm
    %   E   =   Modulo di Young del materiale in GPa
    %   v   =   Modulo di Poisson del materiale
    %   q   =   Funzione carico trasversale che agisce sulla piastra in kPa
    %           e passata in input come function handle @(x, y)
    %   N   =   Numero a cui troncare gli sviluppi in serie
    
    %% CONVERSIONE SPESSORE, MODULO DI YOUNG E CARICO IN SI
    t = 1e-3 * t;
    E = 1e9 * E;
    q = @(x, y) 1e3 * q(x, y);
    
    D = E * t^3 / 12 / (1-v^2);
    
    %% DEFINIZIONE DEGLI ASSI [m]
    X = linspace(0, a, 51);
    Y = linspace(0, b, 51);
    [x, y] = meshgrid(X, Y);
    
    %% CALCOLO COEFFICIENTI PER LO SVILUPPO DI q
    c = zeros(N);
    for m = 1:N
        for n = 1:N
            f = @(x, y) 4/a/b * q(x, y) .* sin(m*pi/a*x) .* sin(n*pi/b*y);
            c(m, n) = integral2(f, 0, a, 0, b);
        end
    end
    
    %% CALCOLO COEFFICIENTI E SVILUPPO DELLA DEFLESSIONE [m]
    A = zeros(N);
    w = 0;
    for m = 1:N
        for n = 1:N
            A(m, n) = 1 / (pi^4 * D * ((m/a)^2 + (n/b)^2)^2) * c(m, n);
            w = w + A(m, n) * sin(m*pi/a*x) .* sin(n*pi/b*y);
        end
    end
    
    %% CONVERSIONE DEFLESSIONE [mm]
    w = 1e3 * w;
    
    %% CALCOLO DEFLESSIONE MASSIMA [mm]
    w_max = max(w(:));
    
    %% PLOT DELLA DEFLESSIONE
    subplot(1, 2, 1)
    surf(y, x, w)
    shading interp
    xlabel('y (m)', 'Interpreter', 'latex')
    ylabel('x (m)', 'Interpreter', 'latex')
    zlabel('w (mm)', 'Interpreter', 'latex')
    title('\textbf{Deflessione della piastra}', ...
        ['Spessore = ' num2str(1e3*t) ' mm'], 'Interpreter', 'latex')
    set(gca, 'ZDir', 'reverse', 'TickLabelInterpreter', 'latex');
    axis([0 b 0 a -w_max*.33 w_max*2])
    text(b/8, a/8, w_max*1.5, ...
        ['Deflessione massima = ' num2str(w_max, 4) ' mm'], 'Interpreter', 'latex')
    hold on
    contour3(y, x, w, linspace(0, w_max, 15), 'k-')
    grid on
    
    %% PLOT DEL CARICO DISTRIBUITO [kPa]
    q_plot = zeros(51);
    for i = 1:51
        for j = 1:51
            q_plot(i, j) = 1e-3 * q(Y(i), X(j));
        end
    end
    subplot(1, 2, 2)
    surf(y, x, q_plot)
    shading interp
    hold on
    surf(y, x, 0*x)
    for i = 1:10:51
        for j = 1:10:51
            quiver3(Y(i), X(j), q_plot(i, j), 0, 0, -q_plot(i, j), 'k', 'LineWidth', 1)
        end
    end
    xlabel('y (m)', 'Interpreter', 'latex')
    ylabel('x (m)', 'Interpreter', 'latex')
    zlabel('q (kPa)', 'Interpreter', 'latex')
    title('\textbf{Carico distribuito sulla piastra}', 'Interpreter', 'latex')
    set(gca, 'TickLabelInterpreter', 'latex')
    contour3(y, x, q_plot, linspace(0, max(q_plot(:)), 15), 'k-')
    grid on
end