function RAMB_OSG(L, a, b, E, sigma_yield, sigma_07, sigma_085, sigma_p)
    %% ARGOMENTI IN INPUT
    %   L           =   Lunghezza della trave in mm
    %   a           =   Lunghezza del lato della sezione in mm
    %   b           =   Lunghezza dell'altro lato della sezione in mm
    %   E           =   Modulo di Young del materiale in GPa
    %   sigma_yield =   Sigma di snervamento del materiale in MPa
    %   sigma_07    =   Sigma_0.7 del materiale in MPa
    %   sigma_085   =   Sigma_0.85 del materiale in MPa
    %   sigma_p     =   Sigma di proporzionalità del materiale in MPa
    
    %% PROPRIETA' SEZIONE
    A = a*b;
    Ix = a * b^3 / 12;
    Iy = a^3 * b / 12;
    rx = sqrt(Ix / A);
    ry = sqrt(Iy / A);
    
    %% CONVERSIONE NEL SI
    E = E * 1e9;
    sigma_yield = sigma_yield * 1e6;
    sigma_07 = sigma_07 * 1e6;
    sigma_085 = sigma_085 * 1e6;
    sigma_p = sigma_p * 1e6;
    
    %% CALCOLO TENSIONE CRITICA E EVENTUALE PLOT
    lam_0 = pi * sqrt(E / sigma_p);
    lam = max([L/rx L/ry]);
    
    sigma_eul = pi^2 * E / lam^2;
    
    if lam >= lam_0
        disp('La sigma critica di instabilità');
        disp(['vale: ' num2str(round(sigma_eul*1e-6)) ' MPa']);
    else
        n = 1 + log(17/7) / log(sigma_07/sigma_085);
        sigma = linspace(0, sigma_yield, 1000);
        Et = E ./ (1 + 3/7*n*(sigma./sigma_07).^(n-1));
        Ef = linspace(0, E, 1000);
        sigma_cr = pi^2 * Ef ./ lam^2;
        eps = sigma./E + 3/7/E/sigma_07^(n-1)*sigma.^n;
        
        e = @(s) s./E + 3/7/E/sigma_07^(n-1)*s.^n;
        sig = @(EE) sigma_07*(7/3/n*(E./EE - 1)).^(1/(n-1));
        sig_cr = @(EE) pi^2 * EE ./ lam^2;
        delta_sig = @(EE) sig(EE) - sig_cr(EE);
        ss = [sigma_p sigma_085 sigma_07];
        ee = e(ss);
        inter = fzero(delta_sig, [Et(1000) E]);
    
        subplot(1, 2, 1)
            plot(eps, 1e-6*sigma, 'k-')
            title('\textbf{Stress-Strain curve approximation}', 'Using Ramberg-Osgood formula', ...
                'Interpreter', 'latex')
            xlabel('Strain', 'Interpreter', 'latex')
            ylabel('Stress (MPa)', 'Interpreter', 'latex')
            axis([0 1.1*eps(1000) 0 1.1e-6*sigma_yield])
            hold on
            plot(ee, ss, 'r.', 'MarkerSize', 16)
            set(gca, 'TickLabelInterpreter', 'latex')
            grid on
        subplot(1, 2, 2)
            plot(1e-9*Ef, 1e-6*sigma_cr, 'b--')
            hold on
            plot(1e-9*Ef, 1e-6*sigma_eul+0*Ef, 'g--')
            plot(1e-9*Et, 1e-6*sigma, 'k')
            plot(1e-9*inter, 1e-6*sig(inter), 'r.', 'MarkerSize', 16)
            text(1.03e-9*inter, 1.015e-6*sig(inter), ...
                [num2str(round(1e-6*sig(inter))) ' MPa'], 'Interpreter', 'latex')
            set(gca, 'TickLabelInterpreter', 'latex')
            title('\textbf{Stresses vs Tangent Modulus diagram and Critical Stress estimation}', ...
                'Using Ramberg-Osgood graphical method', 'Interpreter', 'latex')
            xlabel('Tangent Modulus (GPa)', 'Interpreter', 'latex')
            ylabel('Stresses (MPa)', 'Interpreter', 'latex')
            axis([0 1.1*10^-9*E 0 1.1*10^-6*max([sigma_yield sigma_eul])])
            legend('Real critical Stress', 'Eulerian critical Stress', 'Actual Stress', ...
                'Location', 'southwest', 'Interpreter', 'latex')
            grid on
    end
end