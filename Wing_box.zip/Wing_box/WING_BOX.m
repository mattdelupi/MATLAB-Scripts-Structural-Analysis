function WING_BOX(Sx, Sy, varargin)
    %% INPUTS
    %   Sx          =   Vector containing value of Sx in N and point of application in mm
    %                   (e.g. for a load of -150N applied in point [10mm -27mm]
    %                   it must be [-150 10 -27])
    %   Sy          =   The same as Sx
    %   varargin    =   Many inputs based on the points the section has. For each point the
    %                   format is WING_BOX(..., [x y], Area, web, ...), where web must be
    %                   'L' (line), 'CL' (circle to the left) or 'CR' (circle to the right)
    %                   and represents the web shape which links it with the next one.
    %                   Each numerical value must be expressed in mm and
    %                   the points must be ordered anticlockwise

    %% DEFINE THE ROW VECTOR OF THE CONCENTRATED AREAS
    N = length(varargin);
    Ac = zeros(1, N/3);
    k = 1;
    for i = 2:3:N-1
        Ac(k) = varargin{i};
        k = k + 1;
    end
    k = 1;
    for i = 1:N
        if mod(i-2, 3) ~= 0
            cell{k} = varargin{i};
            k = k + 1;
        end
    end

    %% GET THE SECTION
    [X, Y, kP] = get_section(cell);

    %% GET THE FULL ROW VECTOR OF THE AREAS
    N = length(X);
    A = zeros(1, N);
    k = 1;
    for i = 1:N
        if i == kP(k)
            A(i) = Ac(k);
            if k == length(kP)
                break
            else
                k = k + 1;
            end
        end
    end
    
    %% GET THE NEW REFERENCE FRAME FIXED IN THE CENTROID
    [X, Y, Sx, Sy] = get_centroid_ref(X, Y, A, Sx, Sy);
    
    %% GET THE AREA MOMENTS OF INERTIA
    [Ix, Iy, Ixy] = area_mom_of_inertia(X, Y, A);
    
    %% GET THE SHEAR FLOW
    [qb, qs0] = shear_flow(X, Y, A, Ix, Iy, Ixy, Sx, Sy, kP);
    q = qb + qs0;
    
    %% PLOT THE SHEAR FLOW
    figure
    N = length(X);
    U = zeros(1, N);
    V = U;
    k = 1;
    kP = [kP kP(1)];
    kk = [kP(1:end-1) kP(1)+N];
    for i = 1:N-2
        if i > kk(k+1)
            k = k + 1;
        end

        if mod(i, floor(N/85)) == 0 && sqrt((X(kP(k+1))-X(i))^2+(Y(kP(k+1))-Y(i))^2) >= 2*max(abs(q)) ...
                && sqrt((X(kP(k))-X(i))^2+(Y(kP(k))-Y(i))^2) >= 2*max(abs(q))
            t = atan2(Y(i+1) - Y(i), X(i+1) - X(i));
            U(i+1) = 2*max(abs(q))*cos(t)*q(i)/abs(q(i));
            V(i+1) = 2*max(abs(q))*sin(t)*q(i)/abs(q(i));
        end
    end
    kP = kP(1:end-1);
    quiver(X, Y, U, V, 'off', 'b', 'LineWidth', .75)
    hold on
    k = 1;
    kP = [kP kP(1)+N];
    for i = 1:N-2
        if i == ceil(kP(k) + (kP(k+1) - kP(k)) / 2)
            text(X(i)+.05*max(X), Y(i)-.1*max(Y), ['$' num2str(abs(q(i)), 3) ' N/mm$'], ...
                'Interpreter', 'latex', 'Color', 'b')
            if k == length(kP) - 1
                break
            else
                k = k + 1;
            end
        end
    end
    kP = kP(1:end-1);

    %% PLOT THE SECTION AND THE LOADS
    plot(X, Y, 'k-')
    title('\textbf{Section plot}', 'Interpreter', 'latex')
    xlim([min(X)-40 max(X)+40])
    axis equal
    plot(0, 0, 'r*', 'MarkerSize', 9)
    quiver([Sx(2)-Sx(1)/23 Sy(2)], [Sx(3) Sy(3)-Sy(1)/23], [Sx(1)/25 0], [0 Sy(1)/25], ...
        'k', 'LineWidth', .75, 'AutoScale', 'off')
    if Sx(1) ~= 0
        text(Sx(2)-Sx(1)/23, Sx(3), [num2str(abs(Sx(1))) ' N'], 'Interpreter', 'latex')
    end
    if Sy(1) ~= 0
        text(Sy(2), Sy(3)-Sy(1)/23, [num2str(abs(Sy(1))) ' N'], 'Interpreter', 'latex')
    end
    for i = 1:length(kP)
        plot(X(kP(i)), Y(kP(i)), 'k.', 'MarkerSize', 23)
        text(X(kP(i))+.05*max(X), Y(kP(i))-.1*max(Y), ...
            ['$' num2str(A(kP(i))) ' mm^2$'], 'Interpreter', 'latex')
    end
    grid on
    set(gca, 'TickLabelInterpreter', 'latex')
    xlabel('x (mm)', 'Interpreter', 'latex')
    ylabel('y (mm)', 'Interpreter', 'latex')
    legend('Shear Flow', 'Webs', 'Centroid', 'Loads', 'Concentrated Areas',...
        'Interpreter', 'latex')

end