function [Ix, Iy, Ixy] = area_mom_of_inertia(X, Y, A)
    N = length(X);
    Ix = A.*Y.^2;
    Iy = A.*X.^2;
    Ixy = A.*X.*Y;

    Ix = sum(Ix);
    Iy = sum(Iy);
    Ixy = sum(Ixy);
end