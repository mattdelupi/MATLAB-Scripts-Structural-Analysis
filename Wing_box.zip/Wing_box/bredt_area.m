function A = bredt_area(X, Y)
    N = length(X);
    X = [X(:).' X(1)];
    Y = [Y(:).' Y(1)];
    A = 0;
    for k = 1:N
        A = A + .5 * (X(k+1) + X(k)) * (Y(k+1) - Y(k));
    end
    A = abs(A);
end