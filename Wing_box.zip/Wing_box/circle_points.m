function circle = circle_points(x1, y1, y2, Nt, L, side)
    t = linspace(0, pi, Nt);
    r = L/2;
    xc = x1;
    yc = max(y1, y2) - r;
    switch side
        case 'L'
            if y1 > y2
                x = xc - r*sin(t);
                y = yc + r*cos(t);
            else
                x = xc - r*sin(pi-t);
                y = yc + r*cos(pi-t);
            end
        case 'R'
            if y1 > y2
                x = xc + r*sin(t);
                y = yc + r*cos(t);
            else
                x = xc + r*sin(pi-t);
                y = yc + r*cos(pi-t);
            end
    end
    circle = [x; y];
end