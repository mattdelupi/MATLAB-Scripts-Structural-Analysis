function [X_new, Y_new, Sx_new, Sy_new] = get_centroid_ref(X, Y, A, Sx, Sy)
    Atot = sum(A);
    xc = A.*X./Atot;
    yc = A.*Y./Atot;
    xc = sum(xc);
    yc = sum(yc);

    X_new = X - xc;
    Y_new = Y - yc;
    Sx_new = Sx;
    Sy_new = Sy;
    Sx_new(2:end) = Sx(2:end) - [xc yc];
    Sy_new(2:end) = Sy(2:end) - [xc yc];
end