function [X, Y, kP] = get_section(cell)
    N = length(cell);
    
    cell{N+1} = cell{1};
    N = N + 1;
    k = 1;
    kP = [];
    X = [];
    Y = [];
    for i = 3:2:N
        P2 = cell{i};
        P1 = cell{i-2};
        x1 = P1(1);
        y1 = P1(2);
        x2 = P2(1);
        y2 = P2(2);
        switch cell{i-1}
            case 'L' % Line
                L = max(max(x1, x2) - min(x1, x2), max(y1, y2) - min(y1, y2));
                Nt = ceil(L / .05);
                line = line_points(x1, y1, x2, y2, Nt);
                X = [X line(1, :)];
                Y = [Y line(2, :)];
                kP = [kP k];
                k = k + Nt - 1;
            case 'CL' % Semi Circle to the left
                L = max(y1, y2) - min(y1, y2);
                Nt = ceil(L / .04);
                circle = circle_points(x1, y1, y2, Nt, L, 'L');
                X = [X circle(1, :)];
                Y = [Y circle(2, :)];
                kP = [kP k];
                k = k + Nt - 1;
            case 'CR' % Semi circle to the right
                L = max(y1, y2) - min(y1, y2);
                Nt = ceil(L / .04);
                circle = circle_points(x1, y1, y2, Nt, L, 'R');
                X = [X circle(1, :)];
                Y = [Y circle(2, :)];
                kP = [kP k];
                k = k + Nt - 1;
        end
    end
end