function line = line_points(x1, y1, x2, y2, Nt)
    t = linspace(0, 1, Nt);
    x = x1 + t*(x2 - x1);
    y = y1 + t*(y2 - y1);
    line = [x; y];
end