function [qb, qs0] = shear_flow(X, Y, A, Ix, Iy, Ixy, Sx, Sy, kP)
    N = length(X);
    qb = zeros(1, N);

    Px = Sx(2:end);
    Py = Sy(2:end);
    Sx = Sx(1);
    Sy = Sy(1);

    a = (Sx*Ix - Sy*Ixy) / (Ix*Iy - Ixy^2);
    b = (Sy*Iy - Sx*Ixy) / (Ix*Iy - Ixy^2);

    qb(1) = -a*A(1)*X(1) - b*A(1)*Y(1);
    k = 2;
    for i = 2:N
        if i == kP(k)
            qb(i) = qb(i-1) - a*A(i)*X(i) - b*A(i)*Y(i);
            if k > length(kP)-1
                break
            else
                k = k + 1;
            end
        else
            qb(i) = qb(i-1);
        end
    end

    M = Py(1)*Sy - Px(2)*Sx;
    ds = sqrt(diff([X X(1)]).^2 + diff([Y Y(1)]).^2);
    dy = diff([Y Y(1)]);
    dx = diff([X X(1)]);
    th = zeros(1, length(dx));
    for i = 1:length(th)
        th(i) = atan2(dy(i), dx(i));
    end
    Mb = qb .* ds .* (X.*sin(th) - Y.*cos(th));
    Mb = sum(Mb);
    Ab = bredt_area(X, Y);
    qs0 = (M - Mb) / (2*Ab);
end